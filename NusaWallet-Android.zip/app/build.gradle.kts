import java.time.LocalDate
import java.time.ZoneOffset

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Diisi oleh workflow rilis GitHub (-PappVersionName, -PappVersionCode, -PgithubRepo)
val appVersionName = (project.findProperty("appVersionName") as String?) ?: "1.0.0"
val appVersionCode = (project.findProperty("appVersionCode") as String?)?.toIntOrNull() ?: 10000
// Tanggal rilis (YYYY-MM-DD, UTC). Bisa diisi workflow lewat -PappReleaseDate; bila kosong memakai tanggal build.
val appReleaseDate = (project.findProperty("appReleaseDate") as String?)
    ?: LocalDate.now(ZoneOffset.UTC).toString()
val githubRepo = (project.findProperty("githubRepo") as String?) ?: ""

// Keystore tetap untuk build rilis (dari workflow). Tanpa ini, build rilis tidak ditandatangani.
val keystorePath: String? = System.getenv("KEYSTORE_FILE")

android {
    namespace = "org.nusacoin.nusawallet"
    compileSdk = 34

    defaultConfig {
        applicationId = "org.nusacoin.nusawallet"
        minSdk = 28          // Android 9 (Pie)
        targetSdk = 34
        versionCode = appVersionCode
        versionName = appVersionName
        buildConfigField("String", "RELEASE_DATE", "\"$appReleaseDate\"")
        buildConfigField("String", "GITHUB_REPO", "\"$githubRepo\"")
    }

    buildFeatures {
        buildConfig = true
    }

    signingConfigs {
        if (keystorePath != null && File(keystorePath).exists()) {
            create("release") {
                storeFile = File(keystorePath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS") ?: "nusawallet"
                keyPassword = System.getenv("KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfigs.findByName("release")?.let { signingConfig = it }
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.9.0")
    implementation("androidx.core:core:1.12.0")
}
