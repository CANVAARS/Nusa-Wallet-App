plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Diisi oleh workflow rilis (-PappVersionName=... -PappVersionCode=...); nilai default untuk build lokal/debug
val appVersionName = (project.findProperty("appVersionName") as String?) ?: "1.0"
val appVersionCode = (project.findProperty("appVersionCode") as String?)?.toIntOrNull() ?: 1

// Penandatanganan rilis: dibaca dari environment (diset oleh workflow). Tanpa KEYSTORE_FILE, build lokal tetap jalan.
val keystorePath: String? = System.getenv("KEYSTORE_FILE")?.takeIf { it.isNotBlank() }

android {
    namespace = "org.nusacoin.nusawallet"
    compileSdk = 34

    defaultConfig {
        applicationId = "org.nusacoin.nusawallet"
        minSdk = 28          // Android 9 (Pie)
        targetSdk = 34
        versionCode = appVersionCode
        versionName = appVersionName
    }

    signingConfigs {
        create("release") {
            if (keystorePath != null) {
                storeFile = file(keystorePath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS") ?: "nusawallet"
                // keystore PKCS12 bawaan keytool memakai password yang sama untuk store dan key
                keyPassword = System.getenv("KEY_PASSWORD") ?: System.getenv("KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (keystorePath != null) signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.9.0")
}
