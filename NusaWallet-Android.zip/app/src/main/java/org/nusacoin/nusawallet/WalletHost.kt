package org.nusacoin.nusawallet

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

/**
 * Pusat wallet:
 *  - penyimpanan (storage.local = file privat di filesDir, storage.session = hanya memori),
 *  - "engine": WebView tersembunyi yang menjalankan background.js (logika DApp yang sama dengan ekstensi Chrome),
 *  - router pesan UI/DApp -> engine -> balasan,
 *  - pewaktu auto-lock dan pembuka layar persetujuan (WalletActivity).
 *
 * Kunci privat TIDAK pernah disimpan polos: yang ada di disk hanya `vault` (PBKDF2 + AES-GCM).
 * WIF yang sudah dibuka hanya ada di `session` (memori proses) dan dihapus saat auto-lock / kunci.
 */
object WalletHost {
    const val EXT_ID = "nusa-wallet-android"
    const val APP_HOST = "appassets.androidplatform.net"
    const val WALLET_BASE = "https://$APP_HOST/assets/wallet/"
    const val WALLET_URL = WALLET_BASE + "popup.html"
    private const val ENGINE_URL = WALLET_BASE + "engine.html"
    private const val LOCAL_FILE = "wallet_local.json"

    private val main = Handler(Looper.getMainLooper())
    private lateinit var app: Context

    // ---- engine ----
    private var engine: WebView? = null
    private var engineReady = false
    private val queued = ArrayList<() -> Unit>()
    private val replies = HashMap<Int, (String) -> Unit>()
    private var callSeq = 0
    private val winSeq = AtomicInteger(0)
    private val alarms = HashMap<String, Runnable>()

    // ---- penyimpanan ----
    private val lock = Any()
    private var local = JSONObject()
    private val session = JSONObject()
    private var autolockAt = 0L          // elapsedRealtime (ikut menghitung saat perangkat tidur)

    val assetLoader: WebViewAssetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(app))
            .build()
    }

    /** Panggil dari main thread sebelum memakai wallet (aman dipanggil berulang). */
    fun init(context: Context) {
        if (::app.isInitialized) return
        app = context.applicationContext
        loadLocal()
        createEngine()
    }

    // ===================== engine =====================

    @SuppressLint("SetJavaScriptEnabled")
    private fun createEngine() {
        val wv = WebView(app)
        wv.settings.apply {
            javaScriptEnabled = true
            allowFileAccess = false
            allowContentAccess = false
        }
        wv.addJavascriptInterface(WalletBridge("engine", null, null), "NusaNative")
        wv.webViewClient = object : WebViewClient() {
            // Aset lokal dilayani loader; permintaan jaringan (fetch ke explorer/API) lewat jalur normal.
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            // Engine tidak pernah berpindah halaman.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
        }
        wv.loadUrl(ENGINE_URL)
        engine = wv
    }

    fun onEngineReady() = main.post {
        engineReady = true
        queued.forEach { it() }
        queued.clear()
    }

    private fun evalEngine(js: String) = main.post { engine?.evaluateJavascript(js, null) }

    /** Kirim pesan ke background.js. [senderJson] diisi oleh native (tidak bisa dipalsukan halaman). Main thread. */
    fun relayToEngine(msgJson: String, senderJson: String, cb: (String) -> Unit) {
        val id = ++callSeq
        replies[id] = cb
        val job = {
            engine?.evaluateJavascript(
                "window.__nusaDeliver($id,JSON.parse(${JSONObject.quote(msgJson)}),JSON.parse(${JSONObject.quote(senderJson)}))",
                null
            )
            Unit
        }
        if (engineReady) job() else queued.add(job)
    }

    /** Pesan dari layar wallet (popup.js). */
    fun relayFromUi(ui: WalletBridge, callId: Int, msgJson: String) {
        val sender = JSONObject().put("id", EXT_ID).put("url", WALLET_URL)
        relayToEngine(msgJson, sender.toString()) { resp -> ui.resolve(callId, resp) }
    }

    fun onEngineReply(callId: Int, json: String) {
        main.post { replies.remove(callId)?.invoke(json) }
    }

    // ===================== jendela persetujuan =====================

    fun openWindow(hash: String): Int {
        val id = winSeq.incrementAndGet()
        main.post {
            val i = Intent(app, WalletActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(WalletActivity.EXTRA_HASH, hash)
                .putExtra(WalletActivity.EXTRA_WIN, id)
            app.startActivity(i)
        }
        return id
    }

    /** Jendela persetujuan ditutup (setuju/tolak/ditutup pengguna). Bila belum dijawab, engine menolaknya (kode 4001). */
    fun windowClosed(id: Int) = evalEngine("window.__nusaWindowRemoved($id)")

    // ===================== auto-lock =====================

    fun setAlarm(name: String, ms: Long) {
        if (name == "autolock") synchronized(lock) { autolockAt = SystemClock.elapsedRealtime() + ms }
        main.post {
            alarms.remove(name)?.let { main.removeCallbacks(it) }
            val r = Runnable {
                alarms.remove(name)
                engine?.evaluateJavascript("window.__nusaAlarm(${JSONObject.quote(name)})", null)
            }
            alarms[name] = r
            main.postDelayed(r, ms)
        }
    }

    private fun checkAutolock() {            // dipanggil di dalam synchronized(lock)
        if (autolockAt != 0L && SystemClock.elapsedRealtime() >= autolockAt) {
            session.remove("wif")
            autolockAt = 0L
        }
    }

    // ===================== penyimpanan =====================

    fun kvGetAll(area: String): String = synchronized(lock) {
        if (area == "session") { checkAutolock(); session.toString() } else local.toString()
    }

    fun kvSet(area: String, json: String) {
        val obj = try { JSONObject(json) } catch (e: Exception) { return }
        synchronized(lock) {
            if (area == "session") {
                if (obj.has("wif")) autolockAt = 0L
                copyInto(session, obj)
            } else {
                copyInto(local, obj)
                if (obj.has("vault")) BiometricVault.clear(app)   // vault baru => data biometrik lama tidak valid
                saveLocal()
            }
        }
    }

    fun kvRemove(area: String, keysJson: String) {
        val keys = try { JSONArray(keysJson) } catch (e: Exception) { return }
        synchronized(lock) {
            val target = if (area == "session") session else local
            var vaultRemoved = false
            for (i in 0 until keys.length()) {
                val k = keys.optString(i)
                if (k == "vault") vaultRemoved = true
                target.remove(k)
            }
            if (area == "session") {
                if (!session.has("wif")) autolockAt = 0L
            } else {
                if (vaultRemoved) BiometricVault.clear(app)
                saveLocal()
            }
        }
    }

    private fun copyInto(target: JSONObject, src: JSONObject) {
        val it = src.keys()
        while (it.hasNext()) { val k = it.next(); target.put(k, src.get(k)) }
    }

    private fun loadLocal() {
        try {
            val f = File(app.filesDir, LOCAL_FILE)
            if (f.exists()) local = JSONObject(f.readText())
        } catch (e: Exception) {
            local = JSONObject()
        }
    }

    private fun saveLocal() {
        try {
            val f = File(app.filesDir, LOCAL_FILE)
            val tmp = File(app.filesDir, "$LOCAL_FILE.tmp")
            tmp.writeText(local.toString())
            if (!tmp.renameTo(f)) { f.writeText(local.toString()); tmp.delete() }
        } catch (e: Exception) {
            // gagal menulis: data tetap di memori sampai proses berakhir
        }
    }
}
