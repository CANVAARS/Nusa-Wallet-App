package org.nusacoin.nusawallet

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.json.JSONTokener
import java.util.concurrent.ConcurrentHashMap

/**
 * Penyimpanan wallet Nusa Wallet (padanan chrome.storage di ekstensi) + antrean permintaan DApp.
 *
 * - vault (private key terenkripsi password, PBKDF2 + AES-GCM), account (alamat/public key),
 *   perms (situs yang disetujui), cfg: disimpan di SharedPreferences privat aplikasi.
 * - WIF yang sudah dibuka hanya ada di memori (sessionWif) dan dihapus otomatis oleh timer kunci-otomatis.
 * - Private key TIDAK pernah dikirim ke halaman DApp; DApp hanya menerima alamat, public key, tanda tangan, txid.
 */
object NuxStore {
    private const val PREFS = "nuxwallet"
    private const val PENDING_TIMEOUT_MS = 5 * 60 * 1000L

    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var sessionWif: String? = null
    private val lockTask = Runnable { sessionWif = null }

    class Pending(
        val id: String,
        val method: String,
        val params: JSONObject,
        val origin: String,
        val address: String,
        val reply: (JSONObject) -> Unit
    )

    private val pending = ConcurrentHashMap<String, Pending>()

    @Synchronized
    fun init(context: Context) {
        if (!::prefs.isInitialized) {
            prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        }
    }

    // ---------- storage.local ----------
    fun get(key: String): String? = prefs.getString("local:$key", null)
    fun set(key: String, json: String) { prefs.edit().putString("local:$key", json).apply() }
    fun remove(keys: List<String>) {
        val e = prefs.edit(); keys.forEach { e.remove("local:$it") }; e.apply()
    }

    fun account(): JSONObject? = get("account")?.let { runCatching { JSONObject(it) }.getOrNull() }
    fun perms(): JSONObject = get("perms")?.let { runCatching { JSONObject(it) }.getOrNull() } ?: JSONObject()
    fun savePerms(p: JSONObject) = set("perms", p.toString())

    /** Konfigurasi dengan nilai bawaan yang sama seperti ekstensi. */
    fun cfg(): JSONObject {
        val c = JSONObject()
            .put("explorer", "https://explorer.nusacoin.org")
            .put("api", "https://api.nusacoin.org")
            .put("fee", "0.0001")
            .put("autoLockMin", 15)
        val saved = get("cfg")?.let { runCatching { JSONObject(it) }.getOrNull() }
        saved?.keys()?.forEach { k -> if (!saved.isNull(k) && saved.optString(k).isNotEmpty()) c.put(k, saved.get(k)) }
        return c
    }

    // ---------- sesi (WIF hanya di memori) + kunci otomatis ----------
    fun sessionGet(): String? = sessionWif
    fun sessionSet(wif: String) { sessionWif = wif; touch() }
    fun sessionRemove() { sessionWif = null; main.removeCallbacks(lockTask) }
    fun touch() {
        main.removeCallbacks(lockTask)
        val min = cfg().optInt("autoLockMin", 15).coerceAtLeast(1)
        main.postDelayed(lockTask, min * 60_000L)
    }

    // ---------- antrean persetujuan ----------
    fun addPending(p: Pending) {
        pending[p.id] = p
        main.postDelayed({ resolve(p.id, false, "null", "Permintaan kedaluwarsa", 4001) }, PENDING_TIMEOUT_MS)
    }

    fun pendingJson(id: String): String? = pending[id]?.let {
        JSONObject().put("id", it.id).put("method", it.method).put("params", it.params)
            .put("origin", it.origin).put("address", it.address).toString()
    }

    /** Dipanggil saat jendela persetujuan ditutup tanpa memilih. */
    fun rejectIfPending(id: String) { resolve(id, false, "null", "Pengguna menutup jendela persetujuan", 4001) }

    fun resolve(id: String, approved: Boolean, resultJson: String, message: String, code: Int): Boolean {
        val p = pending.remove(id) ?: return false
        val response: JSONObject = if (!approved) {
            error(if (code != 0) code else 4001, message.ifBlank { "Ditolak pengguna" })
        } else if (p.method == "nux_connect") {
            val acc = account()
            if (acc == null) error(4100, "Wallet belum dibuat.") else {
                val perms = perms(); perms.put(p.origin, System.currentTimeMillis()); savePerms(perms)
                JSONObject().put("result", JSONObject().put("address", acc.optString("address")).put("publicKey", acc.optString("pubkey")))
            }
        } else {
            val value = runCatching { JSONTokener(resultJson).nextValue() }.getOrDefault(JSONObject.NULL)
            JSONObject().put("result", value)
        }
        main.post { p.reply(response) }
        return true
    }

    fun error(code: Int, message: String): JSONObject =
        JSONObject().put("error", JSONObject().put("code", code).put("message", message))
}
