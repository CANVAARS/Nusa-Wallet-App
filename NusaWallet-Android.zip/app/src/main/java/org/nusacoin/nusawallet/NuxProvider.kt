package org.nusacoin.nusawallet

import android.app.Activity
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

/**
 * Menyediakan window.nux (API yang sama persis dengan ekstensi Nusa Wallet) di halaman web
 * yang dibuka di BrowserActivity, sehingga DApp tidak perlu diubah.
 *
 * Keamanan:
 * - Jembatan memakai addWebMessageListener (bukan addJavascriptInterface): origin pengirim diberikan oleh WebView
 *   dan tidak bisa dipalsukan halaman. Hanya frame utama dengan origin https yang dilayani.
 * - Situs harus di-connect (disetujui pengguna) dulu; sign / kirim / tulis data selalu memunculkan layar persetujuan.
 * - Private key tidak pernah masuk ke halaman web.
 */
object NuxProvider {
    private const val JS_NAME = "__nusaNative"
    private val ALLOWED = setOf(
        "nux_connect", "nux_disconnect", "nux_getAddress", "nux_getBalance",
        "nux_signMessage", "nux_sendTransaction", "nux_sendData"
    )
    private const val MAX_OPRETURN = 80
    private val main = Handler(Looper.getMainLooper())

    // Skrip ini dijalankan di awal setiap halaman. API sama dengan inject.js ekstensi.
    private val SCRIPT = """
(function () {
  if (window.nux) return;
  var bridge = window.$JS_NAME;
  if (!bridge) return;
  var pending = {}, seq = 0, listeners = {};
  bridge.onmessage = function (ev) {
    var m; try { m = JSON.parse(ev.data); } catch (e) { return; }
    if (m.event) { (listeners[m.event] || []).forEach(function (fn) { try { fn(m.data); } catch (_) {} }); return; }
    var p = pending[m.id]; if (!p) return; delete pending[m.id];
    if (m.error) { var e = new Error(m.error.message); e.code = m.error.code; p.reject(e); } else p.resolve(m.result);
  };
  function request(args) {
    if (!args || typeof args.method !== 'string') return Promise.reject(new Error('method wajib diisi'));
    return new Promise(function (resolve, reject) {
      var id = ++seq; pending[id] = { resolve: resolve, reject: reject };
      bridge.postMessage(JSON.stringify({ id: id, method: args.method, params: args.params || {} }));
    });
  }
  var nux = Object.freeze({
    isNuxWallet: true, chain: 'nusacoin', symbol: 'NUX',
    request: request,
    connect: function () { return request({ method: 'nux_connect' }); },
    disconnect: function () { return request({ method: 'nux_disconnect' }); },
    getAddress: function () { return request({ method: 'nux_getAddress' }); },
    getBalance: function () { return request({ method: 'nux_getBalance' }); },
    signMessage: function (message) { return request({ method: 'nux_signMessage', params: { message: String(message) } }); },
    sendTransaction: function (o) { return request({ method: 'nux_sendTransaction', params: { to: o && o.to, amount: o && o.amount } }); },
    sendData: function (o) { return request({ method: 'nux_sendData', params: { data: String(o && o.data), encoding: (o && o.encoding) || 'utf8' } }); },
    on: function (ev, fn) { (listeners[ev] = listeners[ev] || []).push(fn); },
    off: function (ev, fn) { listeners[ev] = (listeners[ev] || []).filter(function (f) { return f !== fn; }); }
  });
  Object.defineProperty(window, 'nux', { value: nux, writable: false, configurable: false });
  if (!window.nusa) { try { Object.defineProperty(window, 'nusa', { value: nux, writable: false, configurable: false }); } catch (_) {} }
  window.dispatchEvent(new Event('nux#initialized'));
})();
"""

    /** Pasang jembatan. Panggil SEBELUM webView.loadUrl(). */
    fun install(activity: Activity, webView: WebView) {
        NuxStore.init(activity)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER) ||
            !WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        ) return   // WebView terlalu lama: window.nux tidak tersedia

        val listener = WebViewCompat.WebMessageListener { _, message, sourceOrigin, isMainFrame, replyProxy ->
            onMessage(activity, message.data, sourceOrigin, isMainFrame, replyProxy)
        }
        val strict = setOf("https://*")
        val rules = try {
            WebViewCompat.addWebMessageListener(webView, JS_NAME, strict, listener); strict
        } catch (e: IllegalArgumentException) {
            val all = setOf("*")   // origin tetap diperiksa (harus https) di onMessage
            WebViewCompat.addWebMessageListener(webView, JS_NAME, all, listener); all
        }
        WebViewCompat.addDocumentStartJavaScript(webView, SCRIPT, rules)
    }

    private fun onMessage(
        activity: Activity, data: String?, origin: Uri, isMainFrame: Boolean, proxy: JavaScriptReplyProxy
    ) {
        var id = 0L
        val send: (JSONObject) -> Unit = { o ->
            try { proxy.postMessage(o.put("id", id).toString()) } catch (_: Exception) {}
        }
        try {
            val req = JSONObject(data ?: return)
            id = req.getLong("id")
            val method = req.optString("method")
            val params = req.optJSONObject("params") ?: JSONObject()
            val host = origin.host
            if (!isMainFrame || origin.scheme != "https" || host.isNullOrEmpty()) {
                send(NuxStore.error(4100, "Pengirim tidak valid")); return
            }
            if (method !in ALLOWED) { send(NuxStore.error(4200, "Method tidak didukung: $method")); return }
            val originStr = "https://" + host + (if (origin.port != -1) ":" + origin.port else "")
            handle(activity, method, params, originStr, send)
        } catch (e: Exception) {
            send(NuxStore.error(-32603, e.message ?: "Kesalahan internal"))
        }
    }

    // Logika yang sama dengan handleDapp() di background.js ekstensi
    private fun handle(
        activity: Activity, method: String, params: JSONObject, origin: String, send: (JSONObject) -> Unit
    ) {
        val acc = NuxStore.account()
        val perms = NuxStore.perms()
        val allowed = perms.has(origin)

        if (method == "nux_disconnect") {
            perms.remove(origin); NuxStore.savePerms(perms)
            send(JSONObject().put("result", true)); return
        }
        if (acc == null && method != "nux_connect") {
            send(NuxStore.error(4100, "Wallet belum dibuat. Buka Nusa Wallet di aplikasi.")); return
        }
        if (method == "nux_connect" && allowed && acc != null) {
            send(JSONObject().put("result", JSONObject().put("address", acc.optString("address")).put("publicKey", acc.optString("pubkey"))))
            return
        }
        if (method == "nux_getAddress") {
            send(if (allowed && acc != null) JSONObject().put("result", acc.optString("address"))
                 else NuxStore.error(4100, "Situs belum terhubung. Panggil connect() dulu."))
            return
        }
        if (method == "nux_getBalance") {
            if (!allowed || acc == null) { send(NuxStore.error(4100, "Situs belum terhubung.")); return }
            val addr = acc.optString("address"); val explorer = NuxStore.cfg().optString("explorer")
            Thread {
                val res = try { JSONObject().put("result", fetchBalance(explorer, addr)) }
                          catch (e: Exception) { NuxStore.error(-32603, e.message ?: "Gagal mengambil saldo") }
                main.post { send(res) }
            }.start()
            return
        }

        // connect / signMessage / sendTransaction / sendData -> layar persetujuan
        if (method != "nux_connect" && !allowed) { send(NuxStore.error(4100, "Situs belum terhubung.")); return }
        when (method) {
            "nux_signMessage" -> if (params.opt("message") !is String) {
                send(NuxStore.error(-32602, "message harus string")); return
            }
            "nux_sendTransaction" -> {
                val amount = params.optDouble("amount", Double.NaN)
                if (params.optString("to").isBlank()) { send(NuxStore.error(-32602, "Alamat tujuan wajib diisi")); return }
                if (!(amount > 0)) { send(NuxStore.error(-32602, "amount harus > 0 (dalam NUX)")); return }
            }
            "nux_sendData" -> try {
                params.put("hex", dataToHex(params.optString("data"), params.optString("encoding", "utf8")))
            } catch (e: Exception) { send(NuxStore.error(-32602, e.message ?: "Data tidak valid")); return }
        }
        val id = UUID.randomUUID().toString()
        NuxStore.addPending(NuxStore.Pending(id, method, params, origin, acc?.optString("address") ?: "", send))
        activity.startActivity(WalletActivity.approveIntent(activity, id))
    }

    private fun dataToHex(data: String, encoding: String): String {
        val bytes: ByteArray = when (encoding) {
            "hex" -> {
                if (!Regex("^([0-9a-fA-F]{2})+$").matches(data)) throw IllegalArgumentException("Data hex tidak valid.")
                ByteArray(data.length / 2) { data.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
            }
            "", "utf8" -> data.toByteArray(Charsets.UTF_8)
            else -> throw IllegalArgumentException("encoding harus 'utf8' atau 'hex'")
        }
        if (bytes.isEmpty() || bytes.size > MAX_OPRETURN)
            throw IllegalArgumentException("Data harus 1-$MAX_OPRETURN byte (sekarang ${bytes.size}).")
        return bytes.joinToString("") { "%02x".format(it) }
    }

    // GET {explorer}/ext/getbalance/{address} -> angka NUX (sama dengan C.fetchBalance di nusa-core.js)
    private fun fetchBalance(explorer: String, address: String): Double {
        val base = explorer.trim().trimEnd('/').removeSuffix("/api")
        val conn = URL("$base/ext/getbalance/" + URLEncoder.encode(address, "UTF-8")).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000; conn.readTimeout = 10_000
            if (conn.responseCode !in 200..299) throw IllegalStateException("Gagal mengambil saldo (HTTP ${conn.responseCode})")
            val v = conn.inputStream.bufferedReader().use { it.readText() }.trim().toDoubleOrNull()
            return if (v == null || v.isNaN()) 0.0 else v
        } finally { conn.disconnect() }
    }
}
