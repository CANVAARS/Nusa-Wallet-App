package org.nusacoin.nusawallet

import android.content.Context
import android.webkit.WebResourceResponse
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream

/**
 * Daftar fitur otomatis dari folder assets/features/.
 *
 * Cukup taruh file .html baru di folder itu -> muncul di bagian "Fitur Aplikasi" (tab DApps)
 * tanpa mengubah kode apa pun. Detail tampilan (judul, ikon, deskripsi) dibaca dari tag <meta>
 * di dalam file HTML-nya (lihat features/_TEMPLATE.html).
 *
 * Daftar disajikan lewat https://appassets.androidplatform.net/features-index.json
 * (tanpa JavaScript bridge, jadi tidak menambah celah keamanan).
 */
object Features {
    const val DIR = "features"
    const val INDEX_PATH = "/features-index.json"

    // Halaman inti: dipakai tab Dompet & Toko, tidak ditampilkan sebagai kartu fitur
    private val CORE_FILES = setOf("shop.html", "login.html", "nusa-card.html")
    private const val HEAD_BYTES = 16 * 1024

    private val TAG = Regex("<meta\\s[^>]*>", RegexOption.IGNORE_CASE)
    private val NAME = Regex("name\\s*=\\s*[\"']nusa:([a-z-]+)[\"']", RegexOption.IGNORE_CASE)
    private val CONTENT = Regex("content\\s*=\\s*\"([^\"]*)\"|content\\s*=\\s*'([^']*)'", RegexOption.IGNORE_CASE)
    private val TITLE = Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

    private class Item(val file: String, val meta: Map<String, String>, val fallbackTitle: String) {
        val order: Int get() = meta["order"]?.toIntOrNull() ?: 1000
        val title: String get() = meta["title"] ?: fallbackTitle
    }

    fun indexResponse(context: Context): WebResourceResponse {
        val names = try { context.assets.list(DIR)?.toList() ?: emptyList() } catch (e: Exception) { emptyList() }
        val items = names
            .filter { it.endsWith(".html", true) && !it.startsWith("_") && it.lowercase() !in CORE_FILES }
            .mapNotNull { read(context, it) }
            .sortedWith(compareBy({ it.order }, { it.title.lowercase() }))

        val arr = JSONArray()
        for (it in items) {
            arr.put(JSONObject().apply {
                put("file", it.file)
                put("title", it.title)
                put("titleEn", it.meta["title-en"] ?: it.title)
                put("desc", it.meta["desc"] ?: "")
                put("descEn", it.meta["desc-en"] ?: (it.meta["desc"] ?: ""))
                put("icon", it.meta["icon"] ?: "fa-solid fa-puzzle-piece")
            })
        }
        return WebResourceResponse(
            "application/json", "UTF-8", 200, "OK",
            mapOf("Cache-Control" to "no-store"),
            ByteArrayInputStream(arr.toString().toByteArray(Charsets.UTF_8))
        )
    }

    private fun read(context: Context, file: String): Item? = try {
        val head = context.assets.open("$DIR/$file").use { s ->
            val buf = ByteArray(HEAD_BYTES)
            val n = s.read(buf)
            if (n > 0) String(buf, 0, n, Charsets.UTF_8) else ""
        }
        val meta = HashMap<String, String>()
        for (tag in TAG.findAll(head)) {
            val t = tag.value
            val key = NAME.find(t)?.groupValues?.get(1)?.lowercase() ?: continue
            val c = CONTENT.find(t) ?: continue
            meta[key] = (c.groupValues[1].ifEmpty { c.groupValues[2] }).trim()
        }
        val fallback = TITLE.find(head)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotEmpty() }
            ?: file.removeSuffix(".html").removeSuffix(".HTML").replace('-', ' ').replace('_', ' ')
        Item(file, meta, fallback)
    } catch (e: Exception) {
        null
    }
}
