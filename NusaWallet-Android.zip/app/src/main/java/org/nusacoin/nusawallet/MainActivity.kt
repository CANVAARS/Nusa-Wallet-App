package org.nusacoin.nusawallet

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.os.Message
import android.os.SystemClock
import android.text.TextUtils
import android.webkit.CookieManager
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var saver: FileSaver

    // Izin kamera yang sedang menunggu jawaban pengguna
    private var pendingCameraRequest: PermissionRequest? = null
    // Pemilih file (Upload QR)
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        saver = FileSaver(this)

        // Menyajikan assets/index.html lewat https://appassets.androidplatform.net/
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        setContentView(webView)
        webView.setBackgroundColor(0xFF0B0F19.toInt())

        // Tab Toko (iframe shop.nusachain.org) memakai cookie pihak ketiga; izinkan agar login bisa tersimpan
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false
            // target="_blank" / window.open ditangani di onCreateWindow
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val uri = request.url
                // Situs yang melarang ditampilkan di dalam iframe (Blockspot, QuTrade):
                // buka sebagai halaman penuh di BrowserActivity, iframe diisi tombol "Buka lagi"
                if (!request.isForMainFrame && isFrameBlocked(uri.host)) {
                    openBlockedPage(uri)
                    return blockedPlaceholder(uri)
                }
                return assetLoader.shouldInterceptRequest(uri)
            }

            override fun onPageFinished(view: WebView, url: String) {
                // Ukur ulang tinggi tab iframe (Wallet/Toko/Swap) agar pas di antara header dan menu bawah
                if (Uri.parse(url).host == APP_HOST) {
                    view.evaluateJavascript(FIT_JS, null)
                    // Informasi Rilis di menu Pengaturan (versi & tanggal rilis build ini)
                    view.evaluateJavascript(
                        "if (window.setAppReleaseInfo) setAppReleaseInfo('${BuildConfig.VERSION_NAME}', '${BuildConfig.RELEASE_DATE}');",
                        null
                    )
                }
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                // iframe / sub-resource tetap dimuat di dalam halaman dompet
                if (!request.isForMainFrame) return false
                val uri = request.url
                if (uri.host == APP_HOST) return false
                // Link luar: dibuka di peramban mini terpisah (BrowserActivity)
                Links.open(this@MainActivity, uri)
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {

            // alert() dari halaman HTML -> dialog
            override fun onJsAlert(
                view: WebView,
                url: String,
                message: String,
                result: JsResult
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(R.string.app_name)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            // confirm() dari halaman HTML -> dialog (dipakai saat kirim NUX)
            override fun onJsConfirm(
                view: WebView,
                url: String,
                message: String,
                result: JsResult
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(R.string.app_name)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            // Kamera untuk Scan QR (hanya untuk halaman milik aplikasi, bukan situs luar)
            override fun onPermissionRequest(request: PermissionRequest) {
                val fromApp = request.origin.host == APP_HOST
                val wantsCamera =
                    request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                if (!fromApp || !wantsCamera) {
                    request.deny()
                    return
                }
                if (checkSelfPermission(Manifest.permission.CAMERA) ==
                    PackageManager.PERMISSION_GRANTED
                ) {
                    request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                } else {
                    pendingCameraRequest?.deny()
                    pendingCameraRequest = request
                    requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_CAMERA)
                }
            }

            // Tombol "Upload QR" (input type=file)
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(params.createIntent(), REQ_FILE)
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCallback = null
                    false
                }
            }

            // Link target="_blank" -> peramban mini (BrowserActivity)
            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message
            ): Boolean {
                val temp = WebView(this@MainActivity)
                var handled = false
                temp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        v: WebView,
                        request: WebResourceRequest
                    ): Boolean {
                        if (!handled) {
                            handled = true
                            Links.open(this@MainActivity, request.url)
                            v.post { v.destroy() }
                        }
                        return true
                    }

                    override fun onPageStarted(
                        v: WebView,
                        url: String,
                        favicon: android.graphics.Bitmap?
                    ) {
                        if (!handled && url != "about:blank") {
                            handled = true
                            Links.open(this@MainActivity, Uri.parse(url))
                            v.post { v.destroy() }
                        }
                    }
                }
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = temp
                resultMsg.sendToTarget()
                return true
            }
        }

        // Unduh Kartu (PNG) -> disimpan ke folder Download
        webView.setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            saver.handleDownload(url, contentDisposition, mimeType)
        }

        if (!isOnline()) {
            Toast.makeText(this, R.string.need_internet, Toast.LENGTH_LONG).show()
        }

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl(START_URL)
            UpdateChecker.check(this)
        }
    }

    // ---------- Situs yang menolak iframe ----------

    @Volatile private var lastBlockedUrl: String? = null
    @Volatile private var lastBlockedAt = 0L

    private fun isFrameBlocked(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return FRAME_BLOCKED_HOSTS.any { h == it || h.endsWith(".$it") }
    }

    private fun openBlockedPage(uri: Uri) {
        val key = uri.toString()
        val now = SystemClock.elapsedRealtime()
        synchronized(this) {
            if (key == lastBlockedUrl && now - lastBlockedAt < 2000) return
            lastBlockedUrl = key
            lastBlockedAt = now
        }
        runOnUiThread { Links.open(this, uri) }
    }

    private fun blockedPlaceholder(uri: Uri): WebResourceResponse {
        val host = TextUtils.htmlEncode(uri.host ?: "")
        val url = TextUtils.htmlEncode(uri.toString())
        val html = """<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{margin:0;background:#0b0f19;color:#e5e7eb;font-family:sans-serif;display:flex;
align-items:center;justify-content:center;min-height:100vh;text-align:center}
.c{padding:24px;max-width:320px;font-size:14px;line-height:1.5}
a{display:inline-block;margin-top:16px;padding:12px 22px;border-radius:12px;
background:#10b981;color:#fff;text-decoration:none;font-weight:600}
</style></head><body><div class="c">
$host tidak mengizinkan ditampilkan di dalam halaman lain, jadi dibuka di jendela terpisah di dalam aplikasi.
<br><a href="$url" target="_blank">Buka $host</a>
</div></body></html>"""
        return WebResourceResponse(
            "text/html", "UTF-8", ByteArrayInputStream(html.toByteArray(Charsets.UTF_8))
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            REQ_CAMERA -> {
                val req = pendingCameraRequest
                pendingCameraRequest = null
                if (granted) req?.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                else req?.deny()
            }
            FileSaver.REQ_STORAGE -> saver.onStoragePermissionResult(granted)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_FILE) {
            fileCallback?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            )
            fileCallback = null
        } else {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    @Suppress("DEPRECATION")
    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val info = cm.activeNetworkInfo
        return info != null && info.isConnected
    }

    override fun onResume() {
        super.onResume()
        ApkUpdater.resumePending(this)
    }

    override fun onPause() {
        super.onPause()
        // Tulis cookie ke penyimpanan agar sesi login tetap ada setelah aplikasi ditutup
        CookieManager.getInstance().flush()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val APP_HOST = "appassets.androidplatform.net"
        private const val START_URL = "https://$APP_HOST/assets/index.html"
        private const val FIT_JS = """
(function(){
  var NAV = '.fixed.bottom-0.left-0.right-0';
  function fit(){
    var header = document.getElementById('appHeader');
    var nav = document.querySelector(NAV);
    var top = header ? header.offsetHeight : 0;
    var bottom = nav ? nav.offsetHeight : 0;
    var avail = Math.max(200, window.innerHeight - top - bottom);
    var tabs = document.querySelectorAll('#tab-wallet,#tab-shop,#tab-swap');
    for (var i = 0; i < tabs.length; i++) { tabs[i].style.height = avail + 'px'; }
    document.body.style.paddingBottom = bottom + 'px';
  }
  if (!window.__nusaFitBound) {
    window.__nusaFitBound = true;
    window.addEventListener('resize', fit);
    window.addEventListener('orientationchange', fit);
    if (window.ResizeObserver) {
      var ro = new ResizeObserver(fit);
      var h = document.getElementById('appHeader'); if (h) ro.observe(h);
      var n = document.querySelector(NAV); if (n) ro.observe(n);
    }
  }
  fit(); setTimeout(fit, 400); setTimeout(fit, 1500);
})();
"""
        private const val REQ_CAMERA = 1001
        private const val REQ_FILE = 1003
        // Tambahkan host lain di sini bila ada situs yang menolak dibuka di iframe
        private val FRAME_BLOCKED_HOSTS = listOf("blockspot.io", "qutrade.io")
    }
}
