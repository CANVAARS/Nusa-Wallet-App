package org.nusacoin.nusawallet

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

/**
 * Peramban mini untuk link luar. Sengaja terpisah dari WebView dompet:
 * tidak ada jembatan JavaScript, tidak ada izin kamera, dan tidak berbagi halaman dengan dompet.
 */
class BrowserActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var titleView: TextView
    private lateinit var progress: ProgressBar
    private lateinit var saver: FileSaver
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        saver = FileSaver(this)

        val startUrl = intent.getStringExtra(EXTRA_URL)
        if (startUrl == null) {
            finish()
            return
        }

        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(COLOR_BG)
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(COLOR_BG)
        }
        val closeBtn = TextView(this).apply {
            text = "✕"
            textSize = 20f
            setTextColor(COLOR_TEXT)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { finish() }
        }
        titleView = TextView(this).apply {
            textSize = 14f
            setTextColor(COLOR_TEXT)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            text = Uri.parse(startUrl).host ?: ""
        }
        val externalBtn = TextView(this).apply {
            text = "↗"
            textSize = 20f
            setTextColor(COLOR_TEXT)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener {
                Links.external(this@BrowserActivity, Uri.parse(webView.url ?: startUrl))
            }
        }
        bar.addView(closeBtn)
        bar.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(externalBtn)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(COLOR_GREEN)
            visibility = View.GONE
        }

        webView = WebView(this)
        webView.setBackgroundColor(COLOR_BG)

        root.addView(
            bar,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        root.addView(
            progress,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3))
        )
        root.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            // Tampil pas selebar layar: hormati meta viewport situs (versi mobile),
            // dan situs desktop-only diperkecil otomatis agar muat di layar
            useWideViewPort = true
            loadWithOverviewMode = true
            layoutAlgorithm = WebSettings.LayoutAlgorithm.TEXT_AUTOSIZING
            // Hilangkan penanda "wv" agar situs memberi tata letak mobile penuh seperti Chrome
            userAgentString = userAgentString.replace("; wv)", ")")
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = handleNavigation(request.url)

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String) {
                progress.visibility = View.GONE
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                if (!title.isNullOrBlank()) titleView.text = title
            }

            // Untuk halaman alat yang meminta pilih file (mis. Read-This-File)
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(params.createIntent(), REQ_FILE)
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCallback = null
                    false
                }
            }
        }

        webView.setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            saver.handleDownload(url, contentDisposition, mimeType)
        }

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl(startUrl)
        }
    }

    /** true = sudah ditangani di sini (jangan dimuat di WebView). */
    private fun handleNavigation(uri: Uri): Boolean {
        return when (uri.scheme?.lowercase()) {
            "http", "https" -> {
                if (Links.isDownload(uri)) {
                    Links.external(this, uri)
                    true
                } else {
                    false
                }
            }
            "about", "javascript", "data", "blob" -> false
            "intent" -> {
                openIntentUri(uri.toString())
                true
            }
            else -> {           // tg://, mailto:, market:, dst.
                Links.external(this, uri)
                true
            }
        }
    }

    private fun openIntentUri(value: String) {
        try {
            val i = Intent.parseUri(value, Intent.URI_INTENT_SCHEME)
            i.addCategory(Intent.CATEGORY_BROWSABLE)
            i.component = null
            i.selector = null
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, value, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == FileSaver.REQ_STORAGE) {
            saver.onStoragePermissionResult(
                grantResults.isNotEmpty() &&
                    grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED
            )
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_FILE) {
            fileCallback?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            )
            fileCallback = null
        } else {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        (webView.parent as? ViewGroup)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val EXTRA_URL = "url"
        private const val REQ_FILE = 2003
        private const val COLOR_BG = 0xFF0B0F19.toInt()
        private const val COLOR_TEXT = 0xFFE5E7EB.toInt()
        private const val COLOR_GREEN = 0xFF10B981.toInt()

        fun start(context: Context, url: String) {
            context.startActivity(
                Intent(context, BrowserActivity::class.java).putExtra(EXTRA_URL, url)
            )
        }
    }
}
