package org.nusacoin.nusawallet

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.URLUtil
import android.widget.Toast
import java.io.File
import java.io.IOException

/** Menyimpan unduhan (data: URL, mis. kartu PNG) ke folder Download. */
class FileSaver(private val activity: Activity) {

    private var pending: Triple<ByteArray, String, String>? = null

    fun handleDownload(url: String, contentDisposition: String?, mimeType: String?) {
        if (!url.startsWith("data:")) {
            Links.external(activity, Uri.parse(url))
            return
        }
        val comma = url.indexOf(',')
        if (comma < 0) return
        val meta = url.substring(5, comma)           // contoh: image/png;base64
        val payload = url.substring(comma + 1)
        val bytes = try {
            if (meta.endsWith(";base64")) Base64.decode(payload, Base64.DEFAULT)
            else Uri.decode(payload).toByteArray()
        } catch (e: IllegalArgumentException) {
            Toast.makeText(activity, R.string.save_failed, Toast.LENGTH_LONG).show()
            return
        }
        val mime = mimeType?.takeIf { it.isNotBlank() }
            ?: meta.substringBefore(';').ifBlank { "application/octet-stream" }
        var name = URLUtil.guessFileName("", contentDisposition, mime)
        if (name.startsWith("downloadfile")) {
            name = "NusaWallet_" + System.currentTimeMillis() + name.removePrefix("downloadfile")
        }
        save(bytes, name, mime)
    }

    @Suppress("DEPRECATION")
    private fun save(bytes: ByteArray, name: String, mime: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                }
                val uri = activity.contentResolver
                    .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IOException("insert gagal")
                activity.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            } else {
                // Android 9: butuh izin penyimpanan
                if (activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
                    PackageManager.PERMISSION_GRANTED
                ) {
                    pending = Triple(bytes, name, mime)
                    activity.requestPermissions(
                        arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                        REQ_STORAGE
                    )
                    return
                }
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                var file = File(dir, name)
                var i = 1
                while (file.exists()) {
                    val dot = name.lastIndexOf('.')
                    val base = if (dot > 0) name.substring(0, dot) else name
                    val ext = if (dot > 0) name.substring(dot) else ""
                    file = File(dir, "$base ($i)$ext")
                    i++
                }
                file.outputStream().use { it.write(bytes) }
                MediaScannerConnection.scanFile(
                    activity, arrayOf(file.absolutePath), arrayOf(mime), null
                )
            }
            Toast.makeText(
                activity, activity.getString(R.string.saved_to_downloads, name), Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            Toast.makeText(
                activity,
                activity.getString(R.string.save_failed) + " " + (e.message ?: ""),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun onStoragePermissionResult(granted: Boolean) {
        val p = pending
        pending = null
        if (granted && p != null) save(p.first, p.second, p.third)
        else Toast.makeText(activity, R.string.save_failed, Toast.LENGTH_LONG).show()
    }

    companion object {
        const val REQ_STORAGE = 1002
    }
}
