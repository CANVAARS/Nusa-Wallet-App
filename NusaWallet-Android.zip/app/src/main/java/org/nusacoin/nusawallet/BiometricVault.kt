package org.nusacoin.nusawallet

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Pintasan buka kunci dengan biometrik.
 * Password wallet dienkripsi (AES-GCM) dengan kunci Android Keystore yang HANYA bisa dipakai setelah
 * autentikasi biometrik (per penggunaan) dan otomatis tidak berlaku bila biometrik di perangkat berubah.
 * Password tidak pernah tersimpan polos. Vault wallet itu sendiri tetap dilindungi password.
 */
object BiometricVault {
    private const val KEY_ALIAS = "nusawallet_bio_key"
    private const val FILE = "bio_vault.json"
    private const val TRANSFORM = "AES/GCM/NoPadding"

    fun isAvailable(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 30) {
            val bm = ctx.getSystemService(BiometricManager::class.java) ?: return false
            return bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
                BiometricManager.BIOMETRIC_SUCCESS
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val bm = ctx.getSystemService(BiometricManager::class.java) ?: return false
            @Suppress("DEPRECATION")
            return bm.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
        }
        return ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)
    }

    fun isEnabled(ctx: Context): Boolean = File(ctx.filesDir, FILE).exists()

    fun clear(ctx: Context) {
        try { File(ctx.filesDir, FILE).delete() } catch (_: Exception) {}
        try {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (ks.containsAlias(KEY_ALIAS)) ks.deleteEntry(KEY_ALIAS)
        } catch (_: Exception) {}
    }

    fun save(ctx: Context, iv: ByteArray, ct: ByteArray) {
        val o = JSONObject()
            .put("iv", Base64.encodeToString(iv, Base64.NO_WRAP))
            .put("ct", Base64.encodeToString(ct, Base64.NO_WRAP))
        File(ctx.filesDir, FILE).writeText(o.toString())
    }

    /** Pair(iv, ciphertext) atau null. */
    fun load(ctx: Context): Pair<ByteArray, ByteArray>? = try {
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) null else {
            val o = JSONObject(f.readText())
            Pair(Base64.decode(o.getString("iv"), Base64.NO_WRAP), Base64.decode(o.getString("ct"), Base64.NO_WRAP))
        }
    } catch (e: Exception) { null }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
            .setInvalidatedByBiometricEnrollment(true)
            .build()
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            .apply { init(spec) }.generateKey()
    }

    fun newEncryptCipher(): Cipher = Cipher.getInstance(TRANSFORM).apply { init(Cipher.ENCRYPT_MODE, key()) }

    /** Melempar KeyPermanentlyInvalidatedException bila biometrik perangkat berubah. */
    fun newDecryptCipher(iv: ByteArray): Cipher =
        Cipher.getInstance(TRANSFORM).apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv)) }

    fun authenticate(
        activity: Activity,
        cipher: Cipher,
        title: String,
        onSuccess: (Cipher) -> Unit,
        onError: (String) -> Unit
    ) {
        val prompt = BiometricPrompt.Builder(activity)
            .setTitle(title)
            .setNegativeButton("Batal", activity.mainExecutor) { _, _ -> }
            .build()
        prompt.authenticate(
            BiometricPrompt.CryptoObject(cipher),
            CancellationSignal(),
            activity.mainExecutor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    val c = result.cryptoObject?.cipher
                    if (c != null) onSuccess(c) else onError("Autentikasi gagal.")
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                    // pembatalan oleh pengguna juga masuk ke sini; halaman menampilkan pesannya
                    onError(errString?.toString() ?: "Dibatalkan.")
                }
            }
        )
    }
}
