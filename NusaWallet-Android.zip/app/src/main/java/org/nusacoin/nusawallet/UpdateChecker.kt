package org.nusacoin.nusawallet

import android.app.Activity
import android.app.AlertDialog
import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Mengecek rilis terbaru di GitHub dan menampilkan dialog bila ada versi yang lebih baru. */
object UpdateChecker {

    fun check(activity: Activity) {
        val repo = BuildConfig.GITHUB_REPO
        if (repo.isBlank()) return

        Thread {
            try {
                val conn = URL("https://api.github.com/repos/$repo/releases/latest")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.setRequestProperty("Accept", "application/vnd.github+json")
                conn.setRequestProperty("User-Agent", "NusaWallet-Android")
                if (conn.responseCode != 200) return@Thread

                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val latest = json.optString("tag_name").removePrefix("v")
                if (latest.isBlank() || !isNewer(latest, BuildConfig.VERSION_NAME)) return@Thread

                var apkUrl: String? = null
                val assets = json.optJSONArray("assets")
                if (assets != null) {
                    for (i in 0 until assets.length()) {
                        val a = assets.getJSONObject(i)
                        if (a.optString("name").endsWith(".apk")) {
                            apkUrl = a.optString("browser_download_url")
                            break
                        }
                    }
                }
                val target = apkUrl ?: json.optString("html_url")
                val notes = json.optString("body").trim().take(500)

                activity.runOnUiThread {
                    if (!activity.isFinishing) show(activity, latest, notes, target)
                }
            } catch (e: Exception) {
                // Diam saja: tanpa internet atau terkena batas API, aplikasi tetap jalan normal
            }
        }.start()
    }

    private fun show(activity: Activity, latest: String, notes: String, target: String) {
        val message = buildString {
            append("Versi $latest sudah tersedia (kamu memakai ${BuildConfig.VERSION_NAME}).")
            if (notes.isNotEmpty()) append("\n\n").append(notes)
        }
        AlertDialog.Builder(activity)
            .setTitle("Update tersedia")
            .setMessage(message)
            .setPositiveButton("Unduh") { _, _ -> Links.external(activity, Uri.parse(target)) }
            .setNegativeButton("Nanti", null)
            .show()
    }

    private fun parts(v: String): List<Int> =
        v.split('.', '-', '+').map { p -> p.takeWhile { it.isDigit() }.toIntOrNull() ?: 0 }

    private fun isNewer(latest: String, current: String): Boolean {
        val a = parts(latest)
        val b = parts(current)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }
}
