package org.nusacoin.nusawallet

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/** Aturan pembukaan link: web biasa di dalam aplikasi, file unduhan & skema lain ke aplikasi/browser HP. */
object Links {

    private val downloadExtensions = listOf(
        ".rar", ".zip", ".7z", ".apk", ".exe", ".msi", ".dmg", ".tar", ".gz", ".pdf"
    )

    /**
     * Domain DApp resmi ekosistem Nusachain. Halaman HTTPS di domain ini dibuka dalam mode DApp
     * (peramban mini dengan provider window.nux). Domain lain tetap tanpa jembatan apa pun.
     */
    val DAPP_HOSTS = listOf("nusachain.org", "nusachain.site", "nusacoin.site")

    fun isDappHost(uri: Uri): Boolean {
        if (uri.scheme?.lowercase() != "https") return false
        val h = uri.host?.lowercase() ?: return false
        return DAPP_HOSTS.any { h == it || h.endsWith(".$it") }
    }

    /** Aturan origin WebView untuk menginjeksi window.nux. */
    fun dappOriginRules(): Set<String> =
        DAPP_HOSTS.flatMap { listOf("https://$it", "https://*.$it") }.toSet()

    fun isDownload(uri: Uri): Boolean {
        val path = uri.path?.lowercase() ?: return false
        return downloadExtensions.any { path.endsWith(it) }
    }

    /** Link web biasa dibuka di BrowserActivity; selain itu diserahkan ke aplikasi/browser HP. */
    fun open(activity: Activity, uri: Uri) {
        val scheme = uri.scheme?.lowercase()
        val isWeb = scheme == "http" || scheme == "https"
        if (isWeb && !isDownload(uri)) {
            BrowserActivity.start(activity, uri.toString(), isDappHost(uri))
        } else {
            external(activity, uri)
        }
    }

    fun external(activity: Activity, uri: Uri) {
        try {
            activity.startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(activity, uri.toString(), Toast.LENGTH_SHORT).show()
        }
    }
}
