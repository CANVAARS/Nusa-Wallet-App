package org.nusacoin.nusawallet

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import androidx.webkit.WebViewAssetLoader

/**
 * Layar wallet bawaan (buat/impor kunci, saldo, kirim, situs terhubung) sekaligus layar PERSETUJUAN
 * untuk permintaan DApp (connect, tanda tangan, kirim NUX, tulis data). UI-nya adalah port popup ekstensi
 * (assets/nuxwallet/). WebView ini hanya memuat halaman milik aplikasi; semua link luar dibuka di browser HP.
 */
class WalletActivity : Activity() {

    private lateinit var webView: WebView
    private var approveId: String? = null

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Cegah screenshot / rekam layar: layar ini bisa menampilkan private key
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        NuxStore.init(this)
        approveId = intent.getStringExtra(EXTRA_APPROVE)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        webView.setBackgroundColor(0xFFF4F9FF.toInt())
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportZoom(false)
        }
        // Hanya halaman milik aplikasi yang boleh memuat WebView ini (lihat shouldOverrideUrlLoading)
        webView.addJavascriptInterface(Host(), "NuxHost")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                if (request.url.host == APP_HOST) assetLoader.shouldInterceptRequest(request.url) else null

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == APP_HOST) return false
                Links.external(this@WalletActivity, request.url)   // mis. link txid -> explorer
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@WalletActivity).setTitle(R.string.app_name).setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@WalletActivity).setTitle(R.string.app_name).setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }

            // Dipakai "Tampilkan private key" (minta password)
            override fun onJsPrompt(
                view: WebView, url: String, message: String, defaultValue: String?, result: JsPromptResult
            ): Boolean {
                val input = EditText(this@WalletActivity).apply {
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    setText(defaultValue ?: "")
                }
                AlertDialog.Builder(this@WalletActivity).setTitle(R.string.app_name).setMessage(message).setView(input)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }
        }

        val hash = approveId?.let { "#approve=$it" } ?: ""
        webView.loadUrl("https://$APP_HOST/assets/nuxwallet/wallet.html$hash")
    }

    /** Jembatan untuk shim.js (hanya tersedia di WebView ini; tidak pernah dipasang di halaman DApp). */
    private inner class Host {
        @JavascriptInterface fun storeGet(key: String): String? = NuxStore.get(key)
        @JavascriptInterface fun storeSet(key: String, json: String) = NuxStore.set(key, json)
        @JavascriptInterface fun storeRemove(keysJson: String) {
            val arr = org.json.JSONArray(keysJson)
            NuxStore.remove((0 until arr.length()).map { arr.getString(it) })
        }
        @JavascriptInterface fun sessionGet(): String? = NuxStore.sessionGet()
        @JavascriptInterface fun sessionSet(wif: String) = NuxStore.sessionSet(wif)
        @JavascriptInterface fun sessionRemove() = NuxStore.sessionRemove()
        @JavascriptInterface fun touch() = NuxStore.touch()
        @JavascriptInterface fun getPending(id: String): String? = NuxStore.pendingJson(id)
        @JavascriptInterface fun resolve(id: String, approved: Boolean, resultJson: String, message: String, code: Int): Boolean =
            NuxStore.resolve(id, approved, resultJson, message, code)
        @JavascriptInterface fun close() { runOnUiThread { finish() } }
        @JavascriptInterface fun copy(text: String) {
            runOnUiThread {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("Nusa Wallet", text))
            }
        }
    }

    override fun onDestroy() {
        // Jendela persetujuan ditutup tanpa memilih = ditolak (kode 4001, sama seperti ekstensi)
        if (isFinishing) approveId?.let { NuxStore.rejectIfPending(it) }
        if (::webView.isInitialized) {
            (webView.parent as? android.view.ViewGroup)?.removeView(webView)
            webView.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val APP_HOST = "appassets.androidplatform.net"
        private const val EXTRA_APPROVE = "approve"

        fun start(context: Context) {
            context.startActivity(Intent(context, WalletActivity::class.java))
        }

        fun approveIntent(context: Context, id: String): Intent =
            Intent(context, WalletActivity::class.java).putExtra(EXTRA_APPROVE, id)
    }
}
