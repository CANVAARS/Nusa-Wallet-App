package org.nusacoin.nusawallet

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText

/**
 * Layar wallet (buat/impor, buka kunci, saldo, kirim, pengaturan) dan layar persetujuan permintaan DApp.
 * Memuat assets/wallet/popup.html (UI yang sama dengan ekstensi Chrome) lewat shim chrome.* -> penyimpanan native.
 * Halaman ini hanya boleh memuat aset lokal: setiap navigasi keluar dialihkan ke peramban mini.
 */
class WalletActivity : Activity() {

    private lateinit var webView: WebView
    private var winId = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Layar ini bisa menampilkan private key (cadangan WIF): blokir screenshot dan pratinjau di recent apps
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        WalletHost.init(this)

        winId = intent.getIntExtra(EXTRA_WIN, 0)
        val hash = (intent.getStringExtra(EXTRA_HASH) ?: "")
            .filter { it.isLetterOrDigit() || it == '=' || it == '&' || it == '-' || it == '_' }

        webView = WebView(this)
        webView.setBackgroundColor(0xFFF4F9FF.toInt())
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
        }
        webView.addJavascriptInterface(WalletBridge("ui", this, webView), "NusaNative")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                WalletHost.assetLoader.shouldInterceptRequest(request.url)

            // Tautan di dalam wallet (mis. TXID ke explorer) dibuka di peramban mini, bukan di halaman wallet
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                Links.open(this@WalletActivity, request.url)
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@WalletActivity)
                    .setTitle(R.string.app_name).setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@WalletActivity)
                    .setTitle(R.string.app_name).setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }

            // prompt() dipakai popup.js untuk meminta password (tampilkan private key) -> kolom password
            override fun onJsPrompt(
                view: WebView, url: String, message: String, defaultValue: String?, result: JsPromptResult
            ): Boolean {
                val input = EditText(this@WalletActivity).apply {
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    setText(defaultValue ?: "")
                }
                val dialog = AlertDialog.Builder(this@WalletActivity)
                    .setTitle(R.string.app_name).setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .create()
                dialog.setView(input, 48, 16, 48, 0)
                dialog.show()
                return true
            }
        }

        webView.loadUrl(WalletHost.WALLET_URL + if (hash.isNotEmpty()) "#$hash" else "")
    }

    override fun onDestroy() {
        // Ditutup tanpa dijawab => engine menolak permintaan DApp (sama seperti menutup jendela popup di ekstensi)
        if (isFinishing && winId != 0) WalletHost.windowClosed(winId)
        (webView.parent as? ViewGroup)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_HASH = "hash"
        const val EXTRA_WIN = "win"
    }
}
