package org.nusacoin.nusawallet

import android.app.Activity
import android.net.Uri
import android.webkit.WebView
import android.widget.Toast
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject

/**
 * Menyediakan window.nux untuk DApp di peramban mini (mode DApp).
 *
 * Keamanan:
 *  - Provider hanya diinjeksi ke origin pada daftar [Links.DAPP_HOSTS] (aturan origin WebView, ditegakkan Chromium).
 *  - Hanya frame utama yang dilayani; origin pengirim diambil dari `sourceOrigin` milik Android,
 *    bukan dari data yang dikirim halaman.
 *  - Halaman hanya bisa memanggil 7 method nux_*; jenis pesan internal (touch/get-pending/resolve-pending) tidak bisa dipanggil.
 *  - Setiap connect/kirim/tanda tangan wajib disetujui pengguna di layar persetujuan (WalletActivity).
 */
object DappBridge {
    private val ALLOWED = setOf(
        "nux_connect", "nux_disconnect", "nux_getAddress", "nux_getBalance",
        "nux_signMessage", "nux_sendTransaction", "nux_sendData"
    )
    private var providerJs: String? = null

    fun install(activity: Activity, webView: WebView) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER) ||
            !WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        ) {
            Toast.makeText(activity, R.string.dapp_unsupported, Toast.LENGTH_LONG).show()
            return
        }
        WalletHost.init(activity)
        val rules = Links.dappOriginRules()
        val js = providerJs ?: activity.assets.open("wallet/provider.js").bufferedReader()
            .use { it.readText() }.also { providerJs = it }

        WebViewCompat.addWebMessageListener(
            webView, "nusaNative", rules,
            WebViewCompat.WebMessageListener { _, message, sourceOrigin, isMainFrame, replyProxy ->
                onMessage(message, sourceOrigin, isMainFrame, replyProxy)
            }
        )
        WebViewCompat.addDocumentStartJavaScript(webView, js, rules)
    }

    private fun error(code: Int, message: String) =
        JSONObject().put("code", code).put("message", message)

    private fun originString(u: Uri): String =
        "${u.scheme}://${u.host}" + if (u.port != -1) ":${u.port}" else ""

    private fun onMessage(
        message: WebMessageCompat, sourceOrigin: Uri, isMainFrame: Boolean, reply: JavaScriptReplyProxy
    ) {
        val raw = message.data ?: return
        val req = try { JSONObject(raw) } catch (e: Exception) { return }
        val id = req.optInt("id", 0)
        fun respond(o: JSONObject) {
            try { reply.postMessage(o.put("id", id).toString()) } catch (_: Exception) { /* halaman sudah pindah */ }
        }

        if (!isMainFrame) return respond(JSONObject().put("error", error(4100, "Hanya halaman utama yang boleh terhubung")))
        val method = req.optString("method")
        if (method !in ALLOWED) return respond(JSONObject().put("error", error(4200, "Method tidak didukung: $method")))

        val origin = originString(sourceOrigin)
        val msg = JSONObject()
            .put("type", "dapp-request")
            .put("method", method)
            .put("params", req.optJSONObject("params") ?: JSONObject())
        val sender = JSONObject()
            .put("id", WalletHost.EXT_ID)
            .put("origin", origin)
            .put("tab", JSONObject().put("url", "$origin/"))

        WalletHost.relayToEngine(msg.toString(), sender.toString()) { resp ->
            val r = try { JSONObject(resp) } catch (e: Exception) { null }
            val out = JSONObject()
            when {
                r == null -> out.put("error", error(-32603, "Respons wallet tidak valid"))
                r.has("error") && !r.isNull("error") -> out.put("error", r.get("error"))
                else -> out.put("result", r.opt("result") ?: JSONObject.NULL)
            }
            respond(out)
        }
    }
}
