package org.nusacoin.nusawallet

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Mengunduh APK update langsung di dalam aplikasi (dengan progres), lalu membuka installer Android. */
object ApkUpdater {

    @Volatile private var cancelled = false
    private var pendingInstall: File? = null

    fun start(activity: Activity, url: String, version: String, sizeHint: Long) {
        cancelled = false
        val dp = activity.resources.displayMetrics.density
        val pad = (20 * dp).toInt()

        val label = TextView(activity).apply { text = "Menyiapkan unduhan…" }
        val bar = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = sizeHint <= 0
        }
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            addView(label, ViewGroup.LayoutParams(-1, -2))
            addView(bar, ViewGroup.LayoutParams(-1, -2))
        }
        val dialog = AlertDialog.Builder(activity)
            .setTitle("Mengunduh update $version")
            .setView(box)
            .setCancelable(false)
            .setNegativeButton("Batal") { _, _ -> cancelled = true }
            .create()
        dialog.show()

        Thread {
            var out: File? = null
            try {
                val dir = File(activity.cacheDir, "updates").apply {
                    mkdirs()
                    listFiles()?.forEach { it.delete() } // buang APK update lama
                }
                out = File(dir, "NusaWallet-$version.apk")

                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 20000
                conn.setRequestProperty("User-Agent", "NusaWallet-Android")
                if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")

                val total = if (conn.contentLengthLong > 0) conn.contentLengthLong else sizeHint
                var done = 0L
                var lastUi = 0L

                conn.inputStream.use { input ->
                    out.outputStream().use { output ->
                        val buf = ByteArray(16 * 1024)
                        while (true) {
                            if (cancelled) throw IOException("dibatalkan")
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (total > 0 && now - lastUi > 150) {
                                lastUi = now
                                val pct = (done * 100 / total).toInt().coerceIn(0, 100)
                                val text = "$pct%  (${mb(done)} / ${mb(total)} MB)"
                                activity.runOnUiThread { bar.progress = pct; label.text = text }
                            }
                        }
                    }
                }
                if (total > 0 && done < total) throw IOException("unduhan tidak lengkap")

                val apk = out
                activity.runOnUiThread {
                    dialog.dismiss()
                    if (!activity.isFinishing) install(activity, apk)
                }
            } catch (e: Exception) {
                out?.delete()
                activity.runOnUiThread {
                    dialog.dismiss()
                    if (!cancelled && !activity.isFinishing) {
                        AlertDialog.Builder(activity)
                            .setTitle("Unduhan gagal")
                            .setMessage("Periksa koneksi internet lalu coba lagi.")
                            .setPositiveButton("Coba lagi") { _, _ -> start(activity, url, version, sizeHint) }
                            .setNeutralButton("Buka di browser") { _, _ -> Links.external(activity, Uri.parse(url)) }
                            .setNegativeButton("Batal", null)
                            .show()
                    }
                }
            }
        }.start()
    }

    private fun mb(bytes: Long) = String.format("%.1f", bytes / 1048576.0)

    fun install(activity: Activity, file: File) {
        if (!activity.packageManager.canRequestPackageInstalls()) {
            pendingInstall = file
            AlertDialog.Builder(activity)
                .setTitle("Izin instal diperlukan")
                .setMessage("Unduhan selesai. Aktifkan \"Izinkan dari sumber ini\" untuk Nusa Wallet, lalu kembali ke aplikasi — instalasi akan dilanjutkan otomatis.")
                .setPositiveButton("Buka pengaturan") { _, _ ->
                    activity.startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:${activity.packageName}")
                        )
                    )
                }
                .setNegativeButton("Nanti", null)
                .show()
            return
        }
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.updates", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        activity.startActivity(intent)
    }

    /** Dipanggil dari onResume: lanjutkan instalasi setelah pengguna memberi izin. */
    fun resumePending(activity: Activity) {
        val f = pendingInstall ?: return
        if (activity.packageManager.canRequestPackageInstalls()) {
            pendingInstall = null
            if (f.exists()) install(activity, f)
        }
    }
}
