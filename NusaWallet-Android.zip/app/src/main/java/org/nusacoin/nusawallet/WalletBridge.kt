package org.nusacoin.nusawallet

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.os.Handler
import android.os.Looper
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

/**
 * Jembatan JavaScript untuk halaman MILIK APLIKASI saja (engine tersembunyi dan layar wallet).
 * Tidak pernah dipasang pada WebView yang memuat situs luar.
 *  kind = "engine" : menjalankan background.js
 *  kind = "ui"     : layar wallet (popup.html)
 */
class WalletBridge(
    private val kind: String,
    private val activity: Activity?,
    private val webView: WebView?
) {
    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface fun context(): String = kind
    @JavascriptInterface fun extId(): String = WalletHost.EXT_ID

    // ---- penyimpanan ----
    @JavascriptInterface fun kvGetAll(area: String): String = WalletHost.kvGetAll(area)
    @JavascriptInterface fun kvSet(area: String, json: String) = WalletHost.kvSet(area, json)
    @JavascriptInterface fun kvRemove(area: String, keysJson: String) = WalletHost.kvRemove(area, keysJson)

    // ---- routing pesan ----
    @JavascriptInterface fun toEngine(callId: Int, json: String) {
        if (kind != "ui") return
        main.post { WalletHost.relayFromUi(this, callId, json) }
    }
    @JavascriptInterface fun reply(callId: Int, json: String) { if (kind == "engine") WalletHost.onEngineReply(callId, json) }
    @JavascriptInterface fun engineReady() { if (kind == "engine") WalletHost.onEngineReady() }
    @JavascriptInterface fun setAlarm(name: String, ms: Long) { if (kind == "engine") WalletHost.setAlarm(name, ms) }
    @JavascriptInterface fun openWindow(hash: String): Int = if (kind == "engine") WalletHost.openWindow(hash) else 0

    // ---- UI ----
    @JavascriptInterface fun closeWallet() { if (kind == "ui") main.post { activity?.finish() } }
    @JavascriptInterface fun copy(text: String) {
        if (kind != "ui") return
        main.post {
            val cm = activity?.getSystemService(ClipboardManager::class.java)
            cm?.setPrimaryClip(ClipData.newPlainText("Nusa Wallet", text))
        }
    }

    /** Dipanggil WalletHost: kirim balasan sendMessage ke halaman UI. */
    fun resolve(callId: Int, json: String) {
        try {
            webView?.evaluateJavascript("window.__nusaResolve($callId,${JSONObject.quote(json)})", null)
        } catch (e: Exception) { /* WebView sudah dihancurkan */ }
    }

    // ---- biometrik (hanya UI) ----
    @JavascriptInterface fun biometricAvailable(): Boolean =
        kind == "ui" && activity != null && BiometricVault.isAvailable(activity)

    @JavascriptInterface fun biometricEnabled(): Boolean =
        kind == "ui" && activity != null && BiometricVault.isEnabled(activity)

    @JavascriptInterface fun biometricDisable() {
        if (kind == "ui") activity?.let { BiometricVault.clear(it) }
    }

    /** Password sudah diverifikasi oleh halaman. Dienkripsi dengan kunci Keystore yang butuh biometrik. */
    @JavascriptInterface fun biometricEnable(password: String) {
        if (kind != "ui") return
        main.post {
            val act = activity ?: return@post
            try {
                val cipher = BiometricVault.newEncryptCipher()
                BiometricVault.authenticate(act, cipher, "Aktifkan buka kunci biometrik",
                    onSuccess = { c ->
                        try {
                            BiometricVault.save(act, c.iv, c.doFinal(password.toByteArray(Charsets.UTF_8)))
                            notifyUi("enabled", "")
                        } catch (e: Exception) { notifyUi("error", "Gagal menyimpan: ${e.message}") }
                    },
                    onError = { msg -> notifyUi("error", msg) })
            } catch (e: Exception) {
                notifyUi("error", "Biometrik tidak tersedia: ${e.message}")
            }
        }
    }

    @JavascriptInterface fun biometricUnlock() {
        if (kind != "ui") return
        main.post {
            val act = activity ?: return@post
            val data = BiometricVault.load(act)
            if (data == null) { notifyUi("error", "Biometrik belum diaktifkan."); return@post }
            try {
                val cipher = BiometricVault.newDecryptCipher(data.first)
                BiometricVault.authenticate(act, cipher, "Buka Nusa Wallet",
                    onSuccess = { c ->
                        try { notifyUi("password", String(c.doFinal(data.second), Charsets.UTF_8)) }
                        catch (e: Exception) { notifyUi("error", "Gagal membuka: ${e.message}") }
                    },
                    onError = { msg -> notifyUi("error", msg) })
            } catch (e: KeyPermanentlyInvalidatedException) {
                BiometricVault.clear(act)
                notifyUi("invalidated", "")
            } catch (e: Exception) {
                notifyUi("error", "Biometrik tidak tersedia: ${e.message}")
            }
        }
    }

    private fun notifyUi(kind: String, payload: String) {
        webView?.evaluateJavascript(
            "window.__nusaBio&&window.__nusaBio(${JSONObject.quote(kind)},${JSONObject.quote(payload)})", null
        )
    }
}
