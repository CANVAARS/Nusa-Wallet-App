// Adaptor: membuat wallet.js (hasil port popup ekstensi) berjalan di WebView aplikasi.
// Penyimpanan, sesi (WIF di memori native) dan persetujuan DApp dijembatani ke Kotlin lewat NuxHost.
(function () {
  const H = window.NuxHost;
  const parse = s => { try { return JSON.parse(s); } catch (_) { return undefined; } };
  const keys = k => Array.isArray(k) ? k : [k];
  const local = {
    get: async k => { const o = {}; keys(k).forEach(x => { const v = H.storeGet(x); if (v != null) o[x] = parse(v); }); return o; },
    set: async obj => { Object.keys(obj).forEach(k => H.storeSet(k, JSON.stringify(obj[k]))); },
    remove: async k => { H.storeRemove(JSON.stringify(keys(k))); }
  };
  const session = {
    get: async k => { const o = {}; if (keys(k).includes('wif')) { const w = H.sessionGet(); if (w) o.wif = w; } return o; },
    set: async obj => { if (obj && obj.wif) H.sessionSet(obj.wif); },
    remove: async k => { if (keys(k).includes('wif')) H.sessionRemove(); }
  };
  const sendMessage = async m => {
    switch (m && m.type) {
      case 'touch': H.touch(); return {};
      case 'get-pending': return parse(H.getPending(m.id)) || null;
      case 'resolve-pending':
        return { ok: H.resolve(m.id, !!m.approved, JSON.stringify(m.result === undefined ? null : m.result), m.message || '', m.code || 0) };
      default: return {};   // termasuk 'ping'
    }
  };
  window.chrome = { storage: { local, session }, runtime: { sendMessage } };
  window.close = () => H.close();
  // Clipboard WebView tidak selalu tersedia: pakai salin native
  try {
    if (!navigator.clipboard) Object.defineProperty(navigator, 'clipboard', { value: {}, configurable: true });
    navigator.clipboard.writeText = t => { H.copy(String(t)); return Promise.resolve(); };
  } catch (_) {}
})();
