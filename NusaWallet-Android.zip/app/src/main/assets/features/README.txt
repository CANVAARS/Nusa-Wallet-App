FOLDER FITUR NUSAWALLET
=======================
Semua halaman HTML fitur ada di sini. Cara pakai:

1. Fitur/menu baru   -> taruh file .html di folder ini. Otomatis muncul di tab DApps,
                        bagian "Fitur Aplikasi". Tidak perlu edit kode.
2. Update fitur      -> timpa file yang namanya sama.
3. Hapus fitur       -> hapus filenya.
4. Judul, ikon, deskripsi, urutan kartu -> atur lewat tag <meta name="nusa:..."> di
                        dalam file HTML (contoh lengkap: _TEMPLATE.html).
                        Tanpa tag, judul diambil dari <title>.

File khusus (jangan diganti namanya):
  Nusa-Card.html -> dibuka oleh tab "Dompet" (Nusa Card Wallet)
  shop.html   -> dibuka oleh tab "Toko" di menu bawah
  login.html  -> portal Seller/Admin; dibuka lewat link "login.html" di dalam shop.html
                 (keduanya berada di folder yang sama, jadi link relatif tetap jalan)

Aturan:
- File berawalan "_" (mis. _TEMPLATE.html) diabaikan.
- Pakai link relatif antar file (href="login.html"), bukan alamat penuh.
- Setelah menambah/mengganti file, build ulang APK (push ke GitHub -> workflow Build APK),
  karena folder ini ikut dikemas ke dalam aplikasi.
