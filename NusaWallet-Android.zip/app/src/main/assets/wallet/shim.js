/* Shim API ekstensi (chrome.*) di atas jembatan native Android.
   Dipakai bersama oleh dua konteks:
   - 'engine' : WebView tersembunyi yang menjalankan background.js (logika DApp, perizinan, persetujuan)
   - 'ui'     : WebView layar wallet (popup.html / popup.js)
   Semua penyimpanan ada di sisi native (Kotlin); sesi (WIF terbuka) hanya di memori. */
(function () {
  'use strict';
  const N = window.NusaNative;
  if (!N) { console.error('NusaNative tidak tersedia'); return; }
  const ctx = N.context();                       // 'engine' | 'ui'
  const BASE = location.origin + '/assets/wallet/';
  const parse = s => (s ? JSON.parse(s) : {});

  // ---------- chrome.storage.{local,session} ----------
  function area(name) {
    const pick = (all, keys) => {
      if (keys == null) return all;
      if (typeof keys === 'string') return keys in all ? { [keys]: all[keys] } : {};
      if (Array.isArray(keys)) { const o = {}; keys.forEach(k => { if (k in all) o[k] = all[k]; }); return o; }
      const o = {}; Object.keys(keys).forEach(k => { o[k] = k in all ? all[k] : keys[k]; }); return o;
    };
    return {
      get: async keys => pick(parse(N.kvGetAll(name)), keys),
      set: async obj => { N.kvSet(name, JSON.stringify(obj)); },
      remove: async keys => { N.kvRemove(name, JSON.stringify(Array.isArray(keys) ? keys : [keys])); }
    };
  }

  // ---------- chrome.runtime ----------
  const listeners = [], waiting = {}; let seq = 0;
  const runtime = {
    id: N.extId(),
    getURL: p => BASE + p,
    onMessage: { addListener: fn => listeners.push(fn) },
    sendMessage: msg => new Promise(resolve => {
      const id = ++seq; waiting[id] = resolve;
      N.toEngine(id, JSON.stringify(msg === undefined ? null : msg));
    })
  };
  // balasan untuk sendMessage (dipanggil native di konteks UI)
  window.__nusaResolve = (id, json) => { const r = waiting[id]; delete waiting[id]; if (r) r(json == null ? undefined : JSON.parse(json)); };
  // pesan masuk ke background (dipanggil native di konteks engine)
  window.__nusaDeliver = (callId, msg, sender) => {
    let responded = false, keep = false;
    const sendResponse = resp => { if (responded) return; responded = true; N.reply(callId, JSON.stringify(resp === undefined ? null : resp)); };
    for (const fn of listeners) {
      try { if (fn(msg, sender, sendResponse) === true) keep = true; }
      catch (e) { sendResponse({ error: { code: -32603, message: String((e && e.message) || e) } }); }
    }
    if (!keep && !responded) sendResponse(null);
  };

  // ---------- chrome.alarms (pewaktu ada di native, tahan tidur perangkat) ----------
  const alarmL = [];
  const alarms = {
    create(name, info) { N.setAlarm(String(name), Math.round(((info && info.delayInMinutes) || 1) * 60000)); },
    onAlarm: { addListener: fn => alarmL.push(fn) }
  };
  window.__nusaAlarm = name => alarmL.forEach(fn => { try { fn({ name }); } catch (_) {} });

  // ---------- chrome.windows (jendela persetujuan = WalletActivity) ----------
  const winL = [];
  const windows = {
    create: async o => ({ id: N.openWindow(String(((o && o.url) || '').split('#')[1] || '')) }),
    onRemoved: {
      addListener: fn => winL.push(fn),
      removeListener: fn => { const i = winL.indexOf(fn); if (i >= 0) winL.splice(i, 1); }
    }
  };
  window.__nusaWindowRemoved = id => winL.slice().forEach(fn => { try { fn(id); } catch (_) {} });

  const chromeObj = { runtime, storage: { local: area('local'), session: area('session') }, alarms, windows };
  window.chrome = chromeObj;
  if (window.chrome !== chromeObj) { try { Object.defineProperty(window, 'chrome', { value: chromeObj, configurable: true }); } catch (_) {} }

  if (ctx === 'ui') {
    window.close = () => N.closeWallet();
    try { Object.defineProperty(navigator, 'clipboard', { value: { writeText: async t => { N.copy(String(t)); } }, configurable: true }); } catch (_) {}
  }
})();
