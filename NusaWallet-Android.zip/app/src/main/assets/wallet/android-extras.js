/* Tambahan khusus Android untuk popup.js (popup.js tetap sama dengan versi ekstensi):
   tombol buka kunci biometrik di layar Buka Wallet dan di Pengaturan. */
(function () {
  'use strict';
  const N = window.NusaNative, C = window.NusaCore;
  if (!N || !C) return;
  const $ = id => document.getElementById(id);
  const el = (tag, props) => Object.assign(document.createElement(tag), props);
  const say = (t, ok) => { const m = $('msg'); m.hidden = !t; m.textContent = t || ''; m.className = 'msg' + (ok ? ' ok' : ''); };

  const bioBtn = el('button', { id: 'btnBio', className: 'secondary', textContent: 'Buka dengan biometrik', hidden: true });
  $('btnUnlock').after(bioBtn);
  const setBtn = el('button', { id: 'btnBioSet', className: 'secondary', hidden: true });
  $('btnExport').before(setBtn);

  function refresh() {
    const avail = N.biometricAvailable(), on = N.biometricEnabled();
    bioBtn.hidden = !(avail && on);
    setBtn.hidden = !avail;
    setBtn.textContent = on ? 'Nonaktifkan biometrik' : 'Aktifkan buka kunci biometrik';
  }
  ['vUnlock', 'vSettings'].forEach(id => new MutationObserver(refresh).observe($(id), { attributes: true, attributeFilter: ['hidden'] }));
  refresh();

  bioBtn.onclick = () => { say(''); N.biometricUnlock(); };
  setBtn.onclick = async () => {
    say('');
    if (N.biometricEnabled()) { N.biometricDisable(); refresh(); say('Biometrik dinonaktifkan.', true); return; }
    const pw = prompt('Masukkan password wallet untuk mengaktifkan biometrik:');
    if (pw === null) return;
    try {
      const vault = (await chrome.storage.local.get('vault')).vault;
      await C.decryptSecret(pw, vault);           // verifikasi password dulu
    } catch (e) { say('Password salah.'); return; }
    N.biometricEnable(pw);
  };

  // hasil dari sisi native
  window.__nusaBio = (kind, payload) => {
    if (kind === 'password') { $('unPass').value = payload; $('btnUnlock').click(); }
    else if (kind === 'enabled') { refresh(); say('Biometrik aktif.', true); }
    else if (kind === 'invalidated') { refresh(); say('Data biometrik di perangkat berubah. Aktifkan ulang di Pengaturan.'); }
    else if (kind === 'error') say(payload);
  };
})();
