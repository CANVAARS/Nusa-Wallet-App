// Provider window.nux untuk DApp (Android). API sama persis dengan ekstensi (inject.js);
// bedanya hanya transport: nusaNative.postMessage (WebMessageListener) menggantikan window.postMessage.
(function () {
  if (window.nux) return;
  const bridge = window.nusaNative;            // diinjeksi native hanya pada origin yang diizinkan
  if (!bridge) return;
  const pending = new Map(); let seq = 0; const listeners = {};
  bridge.onmessage = e => {
    let m; try { m = JSON.parse(e.data); } catch (_) { return; }
    if (m.event) { (listeners[m.event] || []).forEach(fn => { try { fn(m.data); } catch (_) {} }); return; }
    const p = pending.get(m.id); if (!p) return; pending.delete(m.id);
    m.error ? p.reject(Object.assign(new Error(m.error.message), { code: m.error.code })) : p.resolve(m.result);
  };
  function request(args) {
    if (!args || typeof args.method !== 'string') return Promise.reject(new Error('method wajib diisi'));
    return new Promise((resolve, reject) => {
      const id = ++seq; pending.set(id, { resolve, reject });
      bridge.postMessage(JSON.stringify({ id, method: args.method, params: args.params || {} }));
    });
  }
  const nux = Object.freeze({
    isNuxWallet: true, chain: 'nusacoin', symbol: 'NUX',
    request,
    connect: () => request({ method: 'nux_connect' }),                  // -> { address, publicKey }
    disconnect: () => request({ method: 'nux_disconnect' }),
    getAddress: () => request({ method: 'nux_getAddress' }),
    getBalance: () => request({ method: 'nux_getBalance' }),            // -> NUX (number)
    signMessage: message => request({ method: 'nux_signMessage', params: { message: String(message) } }),
    sendTransaction: ({ to, amount }) => request({ method: 'nux_sendTransaction', params: { to, amount } }), // amount dalam NUX
    // data: string (utf8) atau hex; encoding: 'utf8' (default) | 'hex'. Maks 80 byte. -> { txid }
    sendData: ({ data, encoding = 'utf8' }) => request({ method: 'nux_sendData', params: { data: String(data), encoding } }),
    on: (ev, fn) => { (listeners[ev] = listeners[ev] || []).push(fn); },
    off: (ev, fn) => { listeners[ev] = (listeners[ev] || []).filter(f => f !== fn); }
  });
  Object.defineProperty(window, 'nux', { value: nux, writable: false, configurable: false });
  window.dispatchEvent(new Event('nux#initialized'));
})();
